#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdio.h>
#include "cgi.h"
#include "estado.h"

#define MAX_BUFFER		10240
#define TAM				10
#define X_INICIAL		8
#define Y_INICIAL		0
#define NUM_INIMIGOS    10
#define NUM_OBSTACULOS  30
#define ESCALAZERO		42
#define ESCALAUM		42

int quadrado (int x)
{
	return (x*x);
}

int dist (int a, int b)
{
	return (quadrado(a) + quadrado (b));
}

int raio_acao_arq (int x, int y, int z, int w)
{
	int a = quadrado (x-z) + quadrado (y-w);
	if (a <= 8) return 1; else return 0; 
}
int posicao_valida(int x, int y)
{
	return (x >= X_INICIAL && y >= Y_INICIAL && x < (TAM + X_INICIAL) && y < (TAM + Y_INICIAL));
}

int posicao_igual(POSICAO p, int x, int y)
{
	return p.x == x && p.y == y;
}

int tem_jogador(ESTADO e, int x, int y)
{
	return posicao_igual(e.jog, x, y);
}

int tem_inimigo(ESTADO e, int x, int y)
{
	int i;

	for(i=0; i<e.num_inimigos; i++)
		if(posicao_igual(e.inimigo[i], x, y))
		return 1;
	return 0;
}

int tem_obstaculo(ESTADO e, int x, int y)
{
	int i;
	
	for(i=0; i<e.num_obstaculos; i++)
		if(posicao_igual(e.obstaculo[i], x, y))
		return 1;
	return 0;
}

int tem_arqueiro(ESTADO e, int x, int y)
{
	int i;

	for(i=0; i<e.num_arqueiros; i++)
		if(posicao_igual(e.arqueiro[i], x, y))
		return 1;
	return 0;
}

int posicao_ocupada(ESTADO e, int x, int y)
{
	if (x==e.goal.x && y==e.goal.y) return 0;
	else return (tem_jogador(e, x, y) || tem_inimigo(e, x, y) || tem_obstaculo(e, x, y) || tem_arqueiro(e, x, y));
}

int posicao_livre(ESTADO e, int x, int y)
{
	if (tem_jogador(e,x,y) || tem_inimigo(e,x,y) || tem_obstaculo(e,x,y) || (x == e.goal.x && y == e.goal.y) || tem_arqueiro (e, x, y)) return 0; 
	else return 1;
}

ESTADO inicializar_inimigo(ESTADO e)
{
	int x, y;

	do {
	x = (rand() % TAM) + X_INICIAL;
	y = (rand() % TAM) + Y_INICIAL;
	}while(posicao_ocupada(e, x, y));
	if (x!=e.goal.x || y!=e.goal.y)
	{
	e.inimigo[(int)e.num_inimigos].x = x;
	e.inimigo[(int)e.num_inimigos].y = y;
	e.num_inimigos++;
	}

	return e;
}

ESTADO inicializar_inimigos(ESTADO e, int num)
{
	int i;

	for(i=0; i<num; i++)
		e = inicializar_inimigo(e);

	return e;
}

ESTADO inicializar_obstaculo(ESTADO e)
{
	int x, y;

	do {
	x = (rand() % TAM) + X_INICIAL;
	y = (rand() % TAM) + Y_INICIAL;
	}while(posicao_ocupada(e, x, y));
	if (x!=e.goal.x || y!=e.goal.y)
	{
	e.obstaculo[(int)e.num_obstaculos].x = x;
	e.obstaculo[(int)e.num_obstaculos].y = y;
	e.num_obstaculos++;
	}

	return e;
}

ESTADO inicializar_obstaculos(ESTADO e, int num)
{
	int i;

	for(i=0; i<num; i++)
		e = inicializar_obstaculo(e);

	return e;
}

ESTADO inicializar_arqueiro(ESTADO e)
{
	int x, y;

	do {
	x = (rand() % TAM) + X_INICIAL;
	y = (rand() % TAM) + Y_INICIAL;
	}while(posicao_ocupada(e, x, y));
	if (x!=e.goal.x || y!=e.goal.y)
	{
	e.arqueiro[(int)e.num_arqueiros].x = x;
	e.arqueiro[(int)e.num_arqueiros].y = y;
	e.num_arqueiros++;
	}

	return e;
}

ESTADO inicializar_arqueiros(ESTADO e, int num)
{
	int i;

	for(i = 0; i < num; i++)
		e = inicializar_arqueiro(e);

	return e;
}


ESTADO inicializar_goal(ESTADO e)
{
	e.goal.x = (rand () % TAM) + X_INICIAL;
	e.goal.y = (rand () % TAM) + Y_INICIAL;

	return e;
}

ESTADO inicializar_car (ESTADO e)
{
	e.vida = 6;
	e.score = 0;
	e.nivel = 1;

	return e;
}

ESTADO inicializar_pagina (ESTADO e)
{
	e.pagina = 0;

	return e;
}

ESTADO continuar(int v, int n, int s)
{
	ESTADO e = {0};
	int z,w;
	int a = 1;

	z = rand () % NUM_INIMIGOS;
	w = rand () % NUM_OBSTACULOS;
	if (w<13) w+=7;
	e.jog.x = (rand () % TAM) + X_INICIAL;
	e.jog.y = (rand() % TAM) + Y_INICIAL;
	e = inicializar_goal(e);	
	e = inicializar_inimigos(e, z);
	e = inicializar_obstaculos(e, w);
	if (n >= 4) a = 2;
	if (n >= 11) a = 3;
	if (n >= 23) a = 4;
	e = inicializar_arqueiros(e, a);
	if (v < 10) 
		e.vida = v+1; 
	else e.vida = v;
	e.nivel = n + 1;
	e.score = s + 50 + 10*v;
	e.pagina = 1;

	return e;
}


ESTADO inicializar()
{
	ESTADO e = {0};
	int z,w;
	z = rand () % NUM_INIMIGOS;
	w = rand () % NUM_OBSTACULOS;
	if (w<13) w+=7;
	e.jog.x = (rand () % TAM) + X_INICIAL;
	e.jog.y = (rand() % TAM) + Y_INICIAL;
	e = inicializar_goal(e);	
	e = inicializar_inimigos(e, z);
	e = inicializar_obstaculos(e, w);
	e = inicializar_arqueiros(e,1);
	e = inicializar_car(e);
	e.pagina = 0;

	return e;
}

ESTADO enimove (ESTADO e, int x)
{
	int i,j;
	int w, c;
	w = e.inimigo[x].x - e.jog.x;
	c = e.inimigo[x].y - e.jog.y;
	int p = dist (w,c);
	int a,b;
	a = b = 0;

	for (i = -1; i <= 1; i++)
	{
		for (j = -1; j<=1; j++)
		{
			int z = e.inimigo[x].x + i;
			int y = e.inimigo[x].y + j;
			w = z - e.jog.x;
			c = y - e.jog.y;
			if (posicao_valida(z, y) && dist(w,c) < p && posicao_livre(e,z,y))
				{
					p = dist(w,c);
					a = i;
					b = j;
				}
		}
	} 
	e.inimigo[x].x += a;
	e.inimigo[x].y += b;

	return e;
}


ESTADO mov_eni(ESTADO e)
{
	int i;

	for (i = 0; i < e.num_inimigos; i++)
		e = enimove(e,i);

	return e;
}

ESTADO arqmove (ESTADO e, int x) 
{
	int i,j,y,z,a,b,c,d;
	c = e.arqueiro[x].x - e.jog.x;
	d = e.arqueiro[x].y - e.jog.y;
	a = b = 0;
	int p = dist (c,d);
	if (p <= 2)
	{
		for (i = -1; i < 2; i++)
		{
			for (j = -1; j < 2; j++)
			{
				y = e.arqueiro[x].x + i;
				z = e.arqueiro[x].y + j;
				c = y - e.jog.x;
				d = z - e.jog.y;
				if (posicao_livre(e,y,z) && dist (c,d) > p && posicao_valida (y,z))
				{
					p = dist (c,d);
					a = i;
					b = j;
				}
			}
		}
	}
	else 
	{
	if (p != 8 && p != 4 && p != 5)
		{
			for (i = -1; i < 2; i++)
			{
				for (j = -1; j < 2; j++)
				{
					y = e.arqueiro[x].x + i;
					z = e.arqueiro[x].y + j;
					c = y - e.jog.x;
					d = z - e.jog.y;
					if (posicao_livre(e,y,z) && dist (c,d) < p && posicao_valida (y,z))
					{
						p = dist (c,d);
						a = i;
						b = j;
					}
				}
			}
		}
	}
	e.arqueiro[x].x += a;
	e.arqueiro[x].y += b;
	return e;	 
}

ESTADO mov_arq(ESTADO e)
{
	int i;
	for (i = 0; i < e.num_arqueiros; i++)
		e = arqmove (e,i);

	return e;
}

void imprime_casa(int x, int y)
{
	char *cor[] = {"#666600", "#555500"};
	int idx = (x + y) % 2;

	QUADRADO(x, y,ESCALAUM, cor[idx]);
}

void imprime_movimento(ESTADO e, int dx, int dy)
{
	ESTADO novo = e;
	int x = e.jog.x + dx;
	int y = e.jog.y + dy;
	char link[MAX_BUFFER];

	if(!posicao_valida(x, y))
		return;
	if(posicao_ocupada(e, x, y))
		return;

	novo.jog.x = x;
	novo.jog.y = y;
	novo = mov_eni (novo);
	novo = mov_arq (novo);
	sprintf(link, "http://localhost/cgi-bin/exemplo?%s", estado2str(novo));
	ABRIR_LINK(link);
	trans(x, y, ESCALAUM);
	FECHAR_LINK;
}

void imprime_jogo(ESTADO e, int x, int y)
{
	ESTADO novo = e;
	char link[MAX_BUFFER];
	
	novo.pagina = 1;
	IMAGEM(x, y, ESCALAZERO, "knight.png");
	sprintf(link, "http://localhost/cgi-bin/exemplo?%s", estado2str(novo));
	ABRIR_LINK(link);
	trans(x, y, ESCALAZERO);
	FECHAR_LINK;	
}

void imprime_continuar(ESTADO e, int x, int y)
{
	ESTADO novo = e;
	char link[MAX_BUFFER];
	
	novo.pagina = 2;
	IMAGEM(x, y, ESCALAZERO, "knight.png");
	sprintf(link, "http://localhost/cgi-bin/exemplo?%s", estado2str(novo));
	ABRIR_LINK(link);
	trans(x, y, ESCALAZERO);
	FECHAR_LINK;
}

void imprime_save(int x, int y)
{
	ESTADO novo = {0};
	novo.pagina = 0;
	char link[MAX_BUFFER];

	IMAGEM(x, y, ESCALAUM, "knight.png");
	sprintf(link, "http://localhost/cgi-bin/exemplo?%s", estado2str(novo));
	ABRIR_LINK(link);
	trans(x, y, ESCALAUM);
	FECHAR_LINK;
}

void imprime_movimentos(ESTADO e)
{
	int dx, dy;

	for(dx=-1;dx<=1; dx++)
		for(dy=-1;dy<=1; dy++)
			imprime_movimento(e,  dx, dy);
}

void imprime_jogador(ESTADO e)
{
	IMAGEM(e.jog.x, e.jog.y, ESCALAUM, "knight.png");
	imprime_movimentos(e);
}

ESTADO ler_estado(char *args)
{
	ESTADO e;
	if(strlen(args) == 0)
		return inicializar();
	e = str2estado(args);
	if (e.vida < 1) return inicializar ();
	if (tem_jogador(e,e.goal.x,e.goal.y)) return continuar(e.vida, e.nivel, e.score);
	else return e;
}

void imprime_inimigos(ESTADO e)
{
	int i;

	for(i = 0; i < e.num_inimigos; i++)
		IMAGEM(e.inimigo[i].x, e.inimigo[i].y, ESCALAUM, "werecreature_25.png");
}

void imprime_obstaculos(ESTADO e)
{
	int i;

	for(i = 0; i < e.num_obstaculos; i++)
		IMAGEM(e.obstaculo[i].x, e.obstaculo[i].y, ESCALAUM, "lava_pool2.png");
}

void imprime_arqueiros(ESTADO e)
{
	int i;

	for(i = 0; i < e.num_arqueiros; i++)
		IMAGEM(e.arqueiro[i].x, e.arqueiro[i].y, ESCALAUM, "arqueiro.png");
}

void imprime_goal(ESTADO e)
{
	IMAGEM(e.goal.x, e.goal.y, ESCALAUM,"trapdoor1.png");
}

void imprime_vida(ESTADO e) 
{
	int i,x,y;
	y = (TAM + Y_INICIAL);
	x = X_INICIAL;

	for (i = 0; i < e.vida; i++)
		IMAGEM(x++, y, ESCALAUM, "heart.png");
	
}

ESTADO ataque_inimigos(ESTADO e, int x, int y)
{
	int i;
	e.score += 20;

	for (i = 0; (e.inimigo[i].x != x || e.inimigo[i].y != y); i++);
	while (i < e.num_inimigos)
	{
		e.inimigo[i] = e.inimigo[i+1];
		i++; 
	}
	e.num_inimigos--;

	return e;
}

ESTADO ataque_arqueiros (ESTADO e, int x , int y)
{
	int i;
	e.score += 33;

	for (i = 0; (e.arqueiro[i].x != x || e.arqueiro[i].y != y); i++);
	while (i < e.num_arqueiros)
	{
		e.arqueiro[i] = e.arqueiro[i+1];
		i++; 
	}
	e.num_arqueiros--;

	return e;
}

void imprime_ataque(ESTADO e, int a, int b)
{
	ESTADO novo = e;
	int i, z, w;
	int x = e.jog.x + a;
	int y = e.jog.y + b;
	char link[MAX_BUFFER];

	if(!posicao_valida(x, y))
		return;
	if(tem_obstaculo(e, x, y))
		return;
	if (tem_inimigo(e, x, y)) 
		novo = ataque_inimigos (e, x, y);
	if (tem_arqueiro(e, x, y)) novo = ataque_arqueiros (e, x, y);
	for(i = 0; i < e.num_inimigos; i++)
	{
		z = novo.inimigo[i].x + a;
		w = novo.inimigo[i].y + b;
		if (tem_jogador(novo, z, w)) 
			novo.vida--;
		else novo = enimove(novo, i);
	}
	for (i = 0; i < e.num_arqueiros; i++)
	{
		z = novo.arqueiro[i].x;
		w = novo.arqueiro[i].y;
		if (raio_acao_arq(x, y, z, w)) novo.vida--;
		else novo = arqmove (novo, i);
	}
	novo = mov_eni (novo);
	sprintf(link, "http://localhost/cgi-bin/exemplo?%s", estado2str(novo));
	ABRIR_LINK(link);
	trans(x, y, ESCALAUM);
	FECHAR_LINK;	
}

void imprime_ataques(ESTADO e)
{
	int dx, dy;

	for(dx=-1;dx<=1; dx++)
		for(dy=-1;dy<=1; dy++)
			imprime_ataque(e,  dx, dy);
}

int main()
{
	int x, y;
	ESTADO e;

	srand(time(NULL));
	e = ler_estado(getenv("QUERY_STRING"));
	if (e.pagina == 0)
	{
		COMECAR_HTML;
		FUNDO("th.png");
		ABRIR_SVG(1000,1000);
		imprime_jogo(e, 14, 3);
		imprime_continuar(e , 14, 8);
		FECHAR_SVG;
		FECHAR_FUNDO;
	}
	if (e.pagina == 1)
	{
		COMECAR_HTML;
		FUNDO("th.png");
		ABRIR_SVG(1000, 1000);
		for(y = Y_INICIAL; y < (TAM + Y_INICIAL); y++)
			for(x = X_INICIAL; x < (TAM + X_INICIAL); x++)
				imprime_casa(x, y);
		imprime_goal(e);
		imprime_inimigos(e);
		imprime_arqueiros(e);
		imprime_obstaculos(e);
		imprime_ataques(e);	
		imprime_jogador(e);
		imprime_vida(e);
		imprime_save(0, 0);
		grava(e);

		FECHAR_SVG;
		FECHAR_FUNDO;
	}
	if (e.pagina == 2)
	{
		e = carrega_estado();
		COMECAR_HTML;
		FUNDO("th.png");
		ABRIR_SVG(1000, 1000);
		for(y = Y_INICIAL; y < (TAM + Y_INICIAL); y++)
			for(x = X_INICIAL; x < (TAM + X_INICIAL); x++)
				imprime_casa(x, y);
		imprime_goal(e);
		imprime_inimigos(e);
		imprime_arqueiros(e);
		imprime_obstaculos(e);
		imprime_ataques(e);	
		imprime_jogador(e);
		imprime_vida(e);
		imprime_save(0, 0);

		FECHAR_SVG;
		FECHAR_FUNDO;
	}

	return 0;
}