#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdio.h>
#include "cgi.h"
#include "estado.h"

#define MAX_BUFFER		10240
#define TAM				10
#define ESCALA			44

int posicao_valida(int x, int y) {
	return x >= 0 && y >= 0 && x < TAM && y < TAM;
}

void imprime_casa(int x, int y) {
	char *cor[] = {"#666600", "#555500"};
	int idx = (x + y) % 2;
	QUADRADO(x, y,ESCALA, cor[idx]);
}
int posicao_igual(POSICAO p, int x, int y){
	return p.x == x && p.y == y;
}

int tem_jogador(ESTADO e, int x, int y){
	return posicao_igual(e.jog, x, y);
}

int tem_inimigo(ESTADO e, int x, int y){
	int i;
	for(i=0; i<e.num_inimigos; i++)
		if(posicao_igual(e.inimigo[i], x, y))
		return 1;
	return 0;
}

int tem_obstaculo(ESTADO e, int x, int y){
	int i;
	
	for(i=0; i<e.num_obstaculos; i++)
		if(posicao_igual(e.obstaculo[i], x, y))
		return 1;
	return 0;
}

int posicao_ocupada(ESTADO e, int x, int y){
	if (x==e.goal.x && y==e.goal.y) return 0;
	else return tem_jogador(e, x, y) || tem_inimigo(e, x, y) || tem_obstaculo(e, x, y);
}

int posicao_livre(ESTADO e, int x, int y){
	if (tem_jogador(e,x,y) || tem_inimigo(e,x,y) || tem_obstaculo(e,x,y) || (x == e.goal.x && y == e.goal.y)) return 0; else return 1;
}

ESTADO inicializar_inimigo(ESTADO e){
	int x, y;
	do {
	x = rand() % TAM;
	y = rand() % TAM;
}	while(posicao_ocupada(e, x, y));
	if (x!=e.goal.x || y!=e.goal.y){
	e.inimigo[(int)e.num_inimigos].x = x;
	e.inimigo[(int)e.num_inimigos].y = y;
	e.num_inimigos++;
	}
	return e;
}

ESTADO inicializar_inimigos(ESTADO e, int num){
	int i;
	for(i=0; i<num; i++)
		e = inicializar_inimigo(e);
	return e;
}

ESTADO inicializar_obstaculo(ESTADO e){
	int x, y;
	do {
	x = rand() % TAM;
	y = rand() % TAM;
}	while(posicao_ocupada(e, x, y));
	if (x!=e.goal.x || y!=e.goal.y){
	e.obstaculo[(int)e.num_obstaculos].x = x;
	e.obstaculo[(int)e.num_obstaculos].y = y;
	e.num_obstaculos++;
	}
	return e;
}

ESTADO inicializar_obstaculos(ESTADO e, int num){
	int i;
	for(i=0; i<num; i++)
		e = inicializar_obstaculo(e);
	return e;
}

ESTADO inicializar_goal(ESTADO e){
	e.goal.x=rand () % TAM;
	e.goal.y=rand () % TAM;
	return e;
}

ESTADO inicializar_car (ESTADO e){
	e.vida = 6;
	e.score = 0;
	e.nivel = 1;
	return e;
}

ESTADO continuar(int v, int n, int s) {
	ESTADO e = {{0}};
	int z,w;
	z=rand () % 10;
	w=rand () % 30;
	if (w<13) w+=7;
	e.jog.x = rand () % TAM;
	e.jog.y = rand() % TAM;
	e = inicializar_goal(e);	
	e = inicializar_inimigos(e, z);
	e = inicializar_obstaculos(e, w);
	if (v < 10) e.vida = v+1; else e.vida = v;
	e.nivel = n + 1;
	e.score = s + 50;
	return e;
}


ESTADO inicializar() {
	ESTADO e = {{0}};
	int z,w;
	z=rand () % 10;
	w=rand () % 30;
	if (w<13) w+=7;
	e.jog.x = rand () % TAM;
	e.jog.y = rand() % TAM;
	e = inicializar_goal(e);	
	e = inicializar_inimigos(e, z);
	e = inicializar_obstaculos(e, w);
	e = inicializar_car(e);
	return e;
}

int quadrado (int x){
	return (x*x);
}

int dist (ESTADO e, int c, int a, int b){
	return (quadrado((e.inimigo[c].x + a) - e.jog.x) + quadrado ((e.inimigo[c].y + b) - e.jog.y));
}

ESTADO enimove (ESTADO e, int x){
	int i,j;
	int p = dist (e,x,0,0);
	int a,b;
	a = b = 0;
	for (i = -1; i <= 1; i++){
		for (j = -1; j<=1; j++){
			int z = e.inimigo[x].x + i;
			int y = e.inimigo[x].y + j;
			if (tem_jogador(e, z, x)) e.vida--;
			else {
			if (posicao_valida(z, y) && dist (e,x,i,j) < p && posicao_livre(e, z, y)) {p = dist (e,x,i,j);a = i;b = j;}
} 
}
} 
	e.inimigo[x].x += a;
	e.inimigo[x].y += b;
	return e;
}


ESTADO mov_eni(ESTADO e){
	int i;
	for (i = 0; i < e.num_inimigos; i++){
		e = enimove (e,i);
}
	return e;
}


void imprime_movimento(ESTADO e, int dx, int dy) {
	ESTADO novo = e;
	int x = e.jog.x + dx;
	int y = e.jog.y + dy;
	char link[MAX_BUFFER];
	if(!posicao_valida(x, y))
		return;
	if(posicao_ocupada(e, x, y))
		return;

	novo.jog.x = x;
	novo.jog.y = y;
	novo = mov_eni (novo);
	sprintf(link, "http://localhost/cgi-bin/exemplo?%s", estado2str(novo));
	ABRIR_LINK(link);
	trans(x, y, ESCALA);
	FECHAR_LINK;
}

void imprime_movimentos(ESTADO e) {
	int dx, dy;
	for(dx=-1;dx<=1; dx++)
		for(dy=-1;dy<=1; dy++)
			imprime_movimento(e,  dx, dy);
}

void imprime_jogador(ESTADO e) {
	IMAGEM(e.jog.x, e.jog.y, ESCALA, "knight.png");
	imprime_movimentos(e);
}

ESTADO ler_estado(char *args) {
	if(strlen(args) == 0)
		return inicializar();
	ESTADO e = str2estado(args);
	if (e.vida < 1) return inicializar ();
	if (tem_jogador(e,e.goal.x,e.goal.y)) return continuar(e.vida, e.nivel, e.score);
	else return e;
}

void imprime_inimigos(ESTADO e) {
	int i;
	for(i = 0; i < e.num_inimigos; i++)
		IMAGEM(e.inimigo[i].x, e.inimigo[i].y, ESCALA, "DwellerN_06.png");
}

void imprime_obstaculos(ESTADO e) {
	int i;
	for(i = 0; i < e.num_obstaculos; i++)
		IMAGEM(e.obstaculo[i].x, e.obstaculo[i].y, ESCALA, "lava_pool2.png");
}

void imprime_goal(ESTADO e){
	IMAGEM(e.goal.x, e.goal.y, ESCALA,"trapdoor1.png");
}

void imprime_vida(ESTADO e) 
{
	int i,x,y;
	y = 10;
	x = 0;
	for (i = 0; i < e.vida; i++)
		IMAGEM(x++, y, ESCALA, "heart.png");
	
}

ESTADO ataque_inimigos(ESTADO e, int x, int y){
	int i;
	for (i = 0; (e.inimigo[i].x != x || e.inimigo[i].y != y); i++);
	while (i < e.num_inimigos){
		e.inimigo[i] = e.inimigo[i+1];
		i++; 
}
	e.num_inimigos--;
	return e;
}

void imprime_ataque(ESTADO e, int a, int b){
	ESTADO novo = e;
	int x = e.jog.x + a;
	int y = e.jog.y + b;
	char link[MAX_BUFFER];
	if(!posicao_valida(x, y))
		return;
	if(tem_obstaculo(e, x, y))
		return;
	if (tem_inimigo(e, x, y)) 
	novo = ataque_inimigos (e, x, y);
	novo = mov_eni (novo);
	sprintf(link, "http://localhost/cgi-bin/exemplo?%s", estado2str(novo));
	ABRIR_LINK(link);
	trans(x, y, ESCALA);
	FECHAR_LINK;	
}


void imprime_ataques(ESTADO e) {
	int dx, dy;
	for(dx=-1;dx<=1; dx++)
		for(dy=-1;dy<=1; dy++)
			imprime_ataque(e,  dx, dy);
}

int main() {
	int x, y;
	srand(time(NULL));
	ESTADO e = ler_estado(getenv("QUERY_STRING"));
	COMECAR_HTML;
	ABRIR_SVG(600, 600);
	for(y = 0; y < 10; y++)
		for(x = 0; x < 10; x++)
			imprime_casa(x, y);
	imprime_goal(e);
	imprime_inimigos(e);
	imprime_obstaculos(e);
	imprime_ataques(e);	
	imprime_jogador(e);
	imprime_vida(e);

	FECHAR_SVG;

	return 0;
}
